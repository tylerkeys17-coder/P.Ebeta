from dataclasses import dataclass


@dataclass
class Quote:
    bid: float
    ask: float
    fee: float = 0.0
    liquidity: float = 0.0


def executable_yes_price(q: Quote):
    # A YES purchase executes at the ask, not the midpoint.
    return q.ask


def market_mid(q: Quote):
    return (q.bid + q.ask) / 2


def net_ev(probability, quote: Quote):
    return probability - executable_yes_price(quote) - quote.fee


def liquidity_penalty(quote: Quote, desired_contracts: int):
    if quote.liquidity <= 0:
        return 1.0
    return min(1.0, desired_contracts / quote.liquidity)

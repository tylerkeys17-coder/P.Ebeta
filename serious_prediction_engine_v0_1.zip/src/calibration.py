import numpy as np


def brier_score(probabilities, outcomes):
    p = np.asarray(probabilities, dtype=float)
    y = np.asarray(outcomes, dtype=float)
    return float(np.mean((p-y)**2))


def log_loss(probabilities, outcomes, eps=1e-12):
    p = np.clip(np.asarray(probabilities, dtype=float), eps, 1-eps)
    y = np.asarray(outcomes, dtype=float)
    return float(-np.mean(y*np.log(p) + (1-y)*np.log(1-p)))


def reliability_bins(probabilities, outcomes, bins=10):
    p = np.asarray(probabilities, dtype=float)
    y = np.asarray(outcomes, dtype=float)
    edges = np.linspace(0, 1, bins+1)
    rows = []

    for i in range(bins):
        mask = (p >= edges[i]) & (p < edges[i+1] if i < bins-1 else p <= edges[i+1])
        if mask.any():
            rows.append({
                "bin_low": float(edges[i]),
                "bin_high": float(edges[i+1]),
                "count": int(mask.sum()),
                "mean_predicted": float(p[mask].mean()),
                "actual_rate": float(y[mask].mean())
            })
    return rows


def calibration_report(probabilities, outcomes):
    return {
        "brier": brier_score(probabilities, outcomes),
        "log_loss": log_loss(probabilities, outcomes),
        "reliability": reliability_bins(probabilities, outcomes)
    }

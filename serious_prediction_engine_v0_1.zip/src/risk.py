import math


def fractional_kelly(p, price, fraction=0.25):
    """Conservative fractional Kelly for a $1 binary contract.

    This is intentionally not a full portfolio optimizer.
    Use only after probability calibration and liquidity checks.
    """
    if price <= 0 or price >= 1:
        return 0.0

    b = (1-price) / price
    q = 1-p
    k = (b*p-q)/b
    return max(0.0, k) * fraction


def bankroll_allocation(bankroll, p, price, max_fraction=0.05):
    k = fractional_kelly(p, price)
    return min(bankroll * k, bankroll * max_fraction)

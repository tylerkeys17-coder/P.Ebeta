import numpy as np


def simulate_top_k(skill_means, skill_sd, n_sim=100000, k=5, seed=42):
    """Generic correlated tournament simulation.

    Replace skill_means/skill_sd with a calibrated score distribution.
    """
    rng = np.random.default_rng(seed)
    means = np.asarray(skill_means, dtype=float)
    sds = np.asarray(skill_sd, dtype=float)

    common = rng.normal(0, 1, n_sim)
    scores = means[None,:] + common[:,None]*0.15 + rng.normal(
        0, sds[None,:], size=(n_sim, len(means))
    )

    # Higher latent skill means better outcome.
    top = np.argsort(scores, axis=1)[:, -k:]
    hits = np.zeros(len(means), dtype=int)

    for col in range(k):
        hits += np.bincount(top[:,col], minlength=len(means))

    return hits / n_sim

import math
from dataclasses import dataclass


@dataclass
class Prediction:
    probability: float
    lower: float
    upper: float
    model_version: str


def clamp(x, lo=1e-6, hi=1-1e-6):
    return max(lo, min(hi, float(x)))


def logit(p):
    p = clamp(p)
    return math.log(p / (1-p))


def sigmoid(x):
    return 1 / (1 + math.exp(-x))


def combine_log_odds(probabilities, weights):
    """Simple ensemble combiner.

    Production version should learn weights only on historical training data
    and freeze them before out-of-sample evaluation.
    """
    if not probabilities:
        raise ValueError("No probabilities supplied")
    if len(probabilities) != len(weights):
        raise ValueError("Probability/weight length mismatch")

    z = sum(w * logit(p) for p, w in zip(probabilities, weights))
    return sigmoid(z / sum(weights))


def binary_ev(p, executable_price, fee=0.0):
    """EV per contract for a $1 binary payout."""
    return p - executable_price - fee


def edge(p, market_price):
    return p - market_price

from dataclasses import dataclass
from typing import List


@dataclass
class Trade:
    timestamp: str
    market: str
    probability: float
    price: float
    outcome: int
    contracts: int


def realized_pnl(trades: List[Trade]):
    pnl = 0.0
    equity = [0.0]

    for t in trades:
        pnl += t.contracts * (t.outcome - t.price)
        equity.append(pnl)

    peak = equity[0]
    max_dd = 0.0
    for x in equity:
        peak = max(peak, x)
        max_dd = max(max_dd, peak-x)

    return {
        "pnl": pnl,
        "max_drawdown": max_dd,
        "trades": len(trades)
    }

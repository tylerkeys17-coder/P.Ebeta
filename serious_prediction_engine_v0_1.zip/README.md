# Serious Prediction Engine v0.1

Goal: a calibrated, auditable prediction engine for prediction markets.
Golf is the first vertical; the architecture is designed for other sports/events.

## Core principle

Never turn a market price directly into a recommendation.

The engine builds an independent probability distribution, calibrates it,
quantifies uncertainty, then compares it with executable market prices.

## Pipeline

DATA INGESTION
  -> feature store
  -> independent probability models
  -> scenario/Monte Carlo simulator
  -> calibration
  -> uncertainty layer
  -> market microstructure
  -> EV
  -> portfolio optimization
  -> backtest/audit
  -> agent interface

## Models

1. Baseline market-implied probability
2. Statistical player/team model
3. Event-specific model
4. Scenario model (weather, injuries, lineups, course conditions)
5. Ensemble combiner
6. Calibration layer
7. Market execution layer

## Non-negotiable validation

- Time-aware train/validation/test splits
- No future-data leakage
- Probability calibration curves
- Brier score
- Log loss
- Reliability diagrams
- Closing-line comparison
- Out-of-sample ROI
- Maximum drawdown
- Tail/stress tests
- Sensitivity to assumptions

## First vertical: golf Top-5

Inputs:
- live leaderboard
- strokes-gained metrics
- recent rounds
- historical performance
- course characteristics
- field strength
- tee times
- withdrawals/injuries
- weather ensemble
- market prices/order book

Output:
P(player finishes Top 5), confidence interval, fair price,
market edge, EV after costs, liquidity-adjusted recommendation.

## Important

This project is an engineering/research framework. It does not guarantee
profit and must be paper-traded/backtested before real-money use.

# Data contract

Every prediction must be timestamped.

The system must store exactly what was known at prediction time.

## Required event data

event_id
timestamp
market_id
market_bid
market_ask
volume
fees

## Sports state

leaderboard/score
player/team identity
lineup/injury state
historical features available before timestamp

## Weather

forecast issuance timestamp
model version
ensemble member
wind
temperature
precipitation
pressure
uncertainty

## Outcome

final result, recorded only after the event.

This prevents accidental look-ahead leakage during backtesting.

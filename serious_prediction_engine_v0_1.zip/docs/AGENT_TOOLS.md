# Agent tool interface

Recommended tools for ChatGPT:

## get_market(market_id)
Returns executable bid/ask, volume, open interest, fees and timestamp.

## get_event_state(event_id)
Returns all sports/event information known at the timestamp.

## predict(event_id, market_id)
Runs the full model and returns:
- probability
- 90% interval
- fair price
- executable market price
- edge
- EV
- model version
- data timestamp

## diagnostics(model_version)
Returns calibration and recent backtest metrics.

## backtest(strategy, start, end)
Runs a time-aware historical simulation.

## IMPORTANT
Do not expose a direct trade execution tool initially.
First establish read-only prediction and backtesting reliability.

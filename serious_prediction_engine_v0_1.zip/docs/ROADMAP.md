# Serious Prediction Engine — build order

### Milestone 1 — Research-grade data foundation
1. Live Kalshi markets/order books.
2. Historical market snapshots.
3. Timestamped sports/event data.
4. Normalized feature store.
5. Automated data-quality checks.

### Milestone 2 — Golf model
1. Player skill model.
2. Round scoring model.
3. Course-fit model.
4. Current tournament state.
5. Tournament Monte Carlo.
6. Top-5 probability.

### Milestone 3 — Weather integration
Use the current Google WeatherNext 3 operational model for new work.
Keep a GenCast adapter for research/benchmarking.

WeatherNext 3 provides global forecasts with hourly initialization and
multi-resolution outputs. GenCast remains useful for research comparisons.

### Milestone 4 — Calibration
1. Historical walk-forward training.
2. Reliability curves.
3. Brier/log loss.
4. Calibration model.
5. Probability confidence intervals.

### Milestone 5 — Market edge
1. Compare fair probability with executable ask.
2. Subtract fees.
3. Account for liquidity/slippage.
4. Reject weak/noisy edges.
5. Rank by risk-adjusted EV.

### Milestone 6 — Backtesting
Replay historical markets exactly as they appeared at each timestamp.
No future information.

### Milestone 7 — Agent
Expose read-only analysis tools:
- get_market
- get_event_state
- run_prediction
- run_backtest
- get_model_diagnostics

Keep trading/write actions separate and approval-gated.

### Milestone 8 — Expansion
After golf is validated:
- NFL
- NBA
- MLB
- soccer
- tennis
- weather markets
- economic/event markets

Do NOT expand before the first vertical demonstrates stable out-of-sample
calibration and edge.

# Model stack

## Layer 0 — Market baseline

Use the executable market price as a benchmark, NOT as the truth.

## Layer 1 — Domain model

Golf:
- strokes gained
- course fit
- field strength
- recent form
- round scoring distribution

Other sports later:
- team/player ratings
- possession/pace
- injuries
- lineups
- schedule/rest
- matchup effects

## Layer 2 — Scenario models

Examples:
- weather
- injury probability
- lineup uncertainty
- game-script scenarios
- course setup

## Layer 3 — Simulation

Generate many possible futures.

## Layer 4 — Calibration

Map raw probabilities to historically reliable probabilities.

Do not deploy an uncalibrated 80% prediction as an 80% prediction.

## Layer 5 — Market execution

Use bid/ask, fees, liquidity and slippage.

The decision should be based on executable expected value.

## Layer 6 — Risk

Use conservative fractional Kelly or another portfolio optimizer,
with hard exposure limits and correlation controls.
